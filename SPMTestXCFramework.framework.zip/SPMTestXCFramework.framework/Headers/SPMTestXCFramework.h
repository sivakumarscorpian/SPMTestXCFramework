//
//  SPMTestXCFramework.h
//  SPMTestXCFramework
//
//  Created by Sivakumar R on 29/09/20.
//

#import <Foundation/Foundation.h>

//! Project version number for SPMTestXCFramework.
FOUNDATION_EXPORT double SPMTestXCFrameworkVersionNumber;

//! Project version string for SPMTestXCFramework.
FOUNDATION_EXPORT const unsigned char SPMTestXCFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SPMTestXCFramework/PublicHeader.h>


